from setuptools import setup

setup(name='whats_time', author='Kantulaev',
      author_email='kantulaev@gmail.com', description='Tell you whats time right now', url='t.me/kantulaev', version='7.7.7', py_modules=['time_today'])
