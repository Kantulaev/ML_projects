import datetime


def func_time_today():
    return datetime.datetime.today().hour
